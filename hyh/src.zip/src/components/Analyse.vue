<template>
<h>这是数据分析页面</h>
</template>

<script>
export default {
  name: 'Analyse'
}
</script>

<style scoped>

</style>
